#!/usr/bin/perl -w

# Steve Parker
# stephen.parker@nih.gov

# print the predicted cleavage pattern for a DNA sequence

use strict;
use Getopt::Long qw(GetOptions);
use PredictCleavagePatterns2;

# get command line options:
my ( $h, $sequence );
GetOptions(
    'h'   => \$h,
    's=s' => \$sequence
);

my $usage = <<USAGE;


    USAGE: perl print_orchid1_2.pl -s <sequence>


    options:
    -h  display this help message
    -s  DNA sequence
	
    
 	NOTES:
 	Four column output format:
 	1. position in sequence
 	2. Base
 	3. ORChID1 pattern
 	4. ORChID2 patern

 	CONSIDERATIONS:
 	1. Sequence length must be greater than 3.
 	2. There are edge artifacts for the 3 positions near each end of a sequence.

    example usage:
    perl print_orchid1_2.pl -s ACGTACGATCGACTAGCATCGACT



USAGE

# check command line arguments and display help if needed
unless ($sequence) { die "$usage"; }
if     ($h)        { die "$usage"; }

# split the bases of the input sequence into an array
my @seq = split '', $sequence;

# do some simple checks on the input sequence:
if ( length($sequence) <= 3 ) {
    die
"\nSequence length must be greater than 3.\n\nRemember there are edge artifacts for the 3 positions near each end of a sequence.\n\n";
}

# predict the cleavage pattern and return the result in an array reference

my $pattern  = &predictOrchid1( uc $sequence );
my $pattern2 = &predictOrchid2( uc $sequence );

my @reverse = reverse( @{$pattern2} );

print "position\tbase\tORChID1\tORChID2\n";

for ( my $p = 0 ; $p <= $#{$pattern} ; $p++ ) {
    my $position = $p + 1;
    print "$position\t$seq[$p]\t${$pattern}[$p]\t${$pattern2}[$p]\n";
}

exit;

